#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_MESSAGE_LEN 1024

int main() {
    int server_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[MAX_MESSAGE_LEN];
    int reuse = 1;

    // Create UDP socket
    if ((server_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address structure
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    //Reuseaddr - permite que use novamente uma porta que foi usada poucos instantes antes
    if(setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) == -1) {
        perror("Erro: setsockopt(SO_REUSEADDR)\n");
        exit(EXIT_FAILURE);
    }

    // Bind socket to the specified port
    if (bind(server_fd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    printf("UDP server is running on port %d...\n", PORT);

    while (1) {
        // Receive message from client
        int len = recvfrom(server_fd, (char *)buffer, MAX_MESSAGE_LEN, 0,
                           (struct sockaddr *)&client_addr, &client_addr_len);
        buffer[len] = '\0';

        printf("Client (%s:%d): %s\n", inet_ntoa(client_addr.sin_addr),
               ntohs(client_addr.sin_port), buffer);

        // Echo message back to client
        sendto(server_fd, (const char *)buffer, strlen(buffer), 0,
               (const struct sockaddr *)&client_addr, client_addr_len);
    }

    close(server_fd);
    return 0;
}

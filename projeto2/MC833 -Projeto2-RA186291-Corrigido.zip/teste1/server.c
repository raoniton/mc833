#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define TCP_PORT 8080
#define UDP_PORT 8888
#define BUFFER_SIZE 1024

int main() {
    int tcp_socket, udp_socket, reuse =1;
    struct sockaddr_in tcp_server_addr, udp_server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];

    // Criação do socket TCP
    tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (tcp_socket == -1) {
        perror("Erro ao criar socket TCP");
        exit(EXIT_FAILURE);
    }

    // Criação do socket UDP
    udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_socket == -1) {
        perror("Erro ao criar socket UDP");
        exit(EXIT_FAILURE);
    }

    // Configuração do endereço do servidor TCP
    memset(&tcp_server_addr, 0, sizeof(tcp_server_addr));
    tcp_server_addr.sin_family = AF_INET;
    tcp_server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    tcp_server_addr.sin_port = htons(TCP_PORT);

    //Reuseaddr - permite que use novamente uma porta que foi usada poucos instantes antes
    if(setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) == -1) {
        perror("Erro: setsockopt(SO_REUSEADDR)\n");
        exit(EXIT_FAILURE);
    }

    // Configuração do endereço do servidor UDP
    memset(&udp_server_addr, 0, sizeof(udp_server_addr));
    udp_server_addr.sin_family = AF_INET;
    udp_server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    udp_server_addr.sin_port = htons(UDP_PORT);

    

    // Associa o socket TCP ao endereço do servidor
    if (bind(tcp_socket, (struct sockaddr *)&tcp_server_addr, sizeof(tcp_server_addr)) == -1) {
        perror("Erro ao fazer bind no socket TCP");
        exit(EXIT_FAILURE);
    }

    // Associa o socket UDP ao endereço do servidor
    if (bind(udp_socket, (struct sockaddr *)&udp_server_addr, sizeof(udp_server_addr)) == -1) {
        perror("Erro ao fazer bind no socket UDP");
        exit(EXIT_FAILURE);
    }

    // Aguarda conexões TCP
    if (listen(tcp_socket, 5) == -1) {
        perror("Erro ao escutar conexões TCP");
        exit(EXIT_FAILURE);
    }

    printf("Servidor TCP/UDP esperando conexões...\n");

    while (1) {
        int client_socket = accept(tcp_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket == -1) {
            perror("Erro ao aceitar conexão TCP");
            exit(EXIT_FAILURE);
        }

        printf("Cliente conectado via TCP\n");
        memset(buffer, 0, 1000);
        // Comunicação via TCP
        recv(client_socket, buffer, BUFFER_SIZE, 0);
        printf("%s\n", buffer);
        if (strcmp(buffer, "DOWNLOAD") == 0) {
            printf("Cliente solicitou download. Mudando para UDP...\n");

            // Envia confirmação via TCP
            send(client_socket, "OK", strlen("OK"), 0);

           

            // Simula envio de dados via UDP
            sendto(udp_socket, "Dados do arquivo via UDP", strlen("Dados do arquivo via UDP"), 0, (struct sockaddr *)&client_addr, client_addr_len);

             // Aguarda por dados via UDP
            recvfrom(udp_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &client_addr_len);
        }

        close(client_socket);
    }

    close(tcp_socket);
    close(udp_socket);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define TCP_PORT 8080
#define UDP_PORT 8888
#define BUFFER_SIZE 1024

int main() {
    int tcp_socket, udp_socket;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Criação do socket TCP
    tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (tcp_socket == -1) {
        perror("Erro ao criar socket TCP");
        exit(EXIT_FAILURE);
    }

    // Criação do socket UDP
    udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_socket == -1) {
        perror("Erro ao criar socket UDP");
        exit(EXIT_FAILURE);
    }

    // Configuração do endereço do servidor
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Endereço IP do servidor
    server_addr.sin_port = htons(TCP_PORT);

    // Conecta-se ao servidor via TCP
    if (connect(tcp_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Erro ao conectar ao servidor TCP");
        exit(EXIT_FAILURE);
    }

    printf("Conectado ao servidor TCP\n");

    // Envia comando para o servidor
    strcpy(buffer, "DOWNLOAD");
    send(tcp_socket, buffer, strlen(buffer), 0);
    memset(buffer, 0, 1000);
    // Recebe confirmação do servidor
    recv(tcp_socket, buffer, BUFFER_SIZE, 0);
    printf("Servidor: %s\n", buffer);
    int n, len;
    if (strncmp(buffer, "OK", 2) == 0) {
        printf("entrou no if\n");
        // Simula download via UDP
        strcpy(buffer, "TEXTO TESTE");
        if(sendto(udp_socket, buffer, strlen(buffer), 0, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1){
            perror("Erro ao enviar via UDP");
            exit(EXIT_FAILURE);
        }

        // Recebe dados via UDP
        recvfrom(udp_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&server_addr, &len);
        printf("Dados recebidos via UDP: %s\n", buffer);
    }

    close(tcp_socket);
    close(udp_socket);

    return 0;
}
